/*
 *  Uzebox Sprite Engine Demo
 *  Copyright (C) 2008  Alec Bourque
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*

About this program:
-------------------

This program demonstrates the new sprites engine which also features full screen scrolling.
The video memory map is arranged as a 32x32 tiles area in which you slide a 22x26 window. 
Up to 31 simultaneous sprites can be displayed on screen at once. However no more 
than 4 sprites can be visible on each scanline due to CPU limitation. Note that in this version, 
sprite #0 must point to a transparent tile. Sprites with lower indexes have higher priority. 
I.e: sprite #1 has higher priority than sprite #5. If more than four sprites crosses the 
same scanline the lower priority one will be completely invisible. This is easy to observe 
if you move the paddle in the middle of the screen. There could be a way to cycle the
sprites so that at worst they would flicker (similar to the NES). 
This is something for the next rev.

Sprites are accessed using a structure with X,Y and tileIndex values. The sprites engine
uses a dedicated tile table that does not need to be the same as for the background tiles. 
This means that, ultimately, it's possible to index 512 tile within a single frame (background+sprites).

The engine also features an "overlay" which is a window on top on the background
that does not scroll. It is useful to display static data like scores, timer, etc. Overlay
height and visibily are controllable at runtime. In this version, the overlay can only appear 
at the top. The maximum height in tiles to allocate is a custom compilation option.

Note that due to the non-binary aligment of the tiles width(6), the caller needs to 
perform X wrapping before calling the SetScrolling() function. Wrapping happens 
at value X_SCROLL_WRAP (see uzeboxVideoEngine.c for details). Y Scrolling doesnt 
need this because it wraps automatically at 0xff. The sprites positions
are independant of the background scrolling posisition. To quickly turn off a 
sprite, set its Y position to -1 (or out of screen if you prefer). Finally,
it worth noting that horizontal scrolling was not trivial and the current method
requires around 9K of program space due to unrolled loops. If your games do not
need horizontal scrolling (i.e.: a "River Raid" game), you can specifiy a custom compilation option
to remove the code for this functionnality.


Hope you have fun with it!


Uze


See Also:
---------
kernel/uzebox.h: API functions, varibles and defines.
kernel/defines.h: Custom compilation options information

*/

#include <stdbool.h>
#include <avr/io.h>
#include <stdlib.h>
#include <avr/pgmspace.h>

#include "kernel/defines.h"
#include "kernel/uzebox.h"

//import tiles
#include "data/arkanoid.map.inc"
#include "data/arkanoid.pic.inc"

//always put fonts tile right after tour main tileset
#include "data/fonts.pic.inc"
#include "data/spr.pic.inc"

//sprites data
#include "data/arkanoid_sprites.pic.inc"


struct SpriteStruct sprites[32]; // create the sprites

const char strDemo[] PROGMEM="SPRITE ENGINE DEMO";
const char strCopy[] PROGMEM="\\2008 UZE - GPL V3";
const char strStart[] PROGMEM= "    START = OVERLAY";
const char strInfo1[] PROGMEM= "SCORES GOES HERE! :)";
const char strX[] PROGMEM="X:";
const char strY[] PROGMEM="Y:";

unsigned char vx=60,vy=195,sx=0,sy=0,overlayHeight=3;

void MoveVaus(unsigned char vx,unsigned char vy);
unsigned char processControls(void);

int main(){	
	unsigned char x[32],y[32];
	char xdir[32],ydir[32];
	unsigned char i;

	SetSpritesTileTable(arkanoid_sprites_tileset);
	SetTileTable(arkanoid_tileset);
	SetFontTilesIndex(ARKANOID_TILESET_SIZE);

	ClearVram();
	SetOverlay(OVERLAY_PRI_HI+overlayHeight);

	DrawMap2(0,0,map_main);	
	DrawMap2(0,OVERLAY_ROW,map_logo);

	Print(2,27,strDemo);
	Print(2,28,strCopy);
	Print(0,30,strStart);

	sprites[0].tileIndex=0;


	for(i=9;i<32;i++){
		sprites[i].tileIndex=1;			
	}


	sprites[1].tileIndex=24;
	sprites[2].tileIndex=25;
	sprites[3].tileIndex=26;
	sprites[4].tileIndex=27;
	
	sprites[5].tileIndex=28;
	sprites[6].tileIndex=29;
	sprites[7].tileIndex=30;
	sprites[8].tileIndex=31;

	MoveVaus(vx,vy);

	//randomize balls locations
	srand(16);
	for(i=9;i<32;i++){

		x[i]=(unsigned char)(rand() % 110)+2;

		if((unsigned char)(rand() % 16)<8){
			ydir[i]=1;
		}else{
			ydir[i]=-1;
		}
		y[i]=((unsigned char)(rand() % 180))+2;
		if((unsigned char)(rand() % 16)<10){
			xdir[i]=1;
		}else{
			xdir[i]=-1;
		}		

	}	


	while(1){

		//syncronize gameplay on vsync (30 hz)	
		WaitVsync(1);
		
		
		//balls "physics" :)
		for(i=5;i<32;i++){	
			x[i]+=xdir[i];
			if(x[i]>125 && xdir[i]==1){
				xdir[i]=-1;
			}
			if(x[i]<13 && xdir[i]==-1){
				xdir[i]=1;
			}

			y[i]+=ydir[i];
			if(y[i]>=188 && ydir[i]==1){
				ydir[i]=-1;
			}
			if(y[i]<4 && ydir[i]==-1){
				ydir[i]=1;
			}
			
			sprites[i].x=x[i];
			sprites[i].y=y[i];

		}


		processControls();
		MoveVaus(vx,vy);

		Print(5,12,strX);
		PrintByte(9,12,sx);

		Print(12,12,strY);	
		PrintByte(16,12,sy);

	
	}
}


//updates the (x,y) coordinates of the paddle
void MoveVaus(unsigned char vx,unsigned char vy){
	sprites[1].x=vx;
	sprites[1].y=vy;
	sprites[2].x=vx+6;
	sprites[2].y=vy;
	sprites[3].x=vx+12;
	sprites[3].y=vy;
	sprites[4].x=vx+18;
	sprites[4].y=vy;

	sprites[5].x=vx;
	sprites[5].y=vy+8;
	sprites[6].x=vx+6;
	sprites[6].y=vy+8;
	sprites[7].x=vx+12;
	sprites[7].y=vy+8;
	sprites[8].x=vx+18;
	sprites[8].y=vy+8;
}



unsigned char processControls(void){
	static int lastbuttons=0,menu=0;
	unsigned int joy=ReadJoypad(0);



	if((joy&BTN_START) && !(lastbuttons&BTN_START)){
		menu++;
		if(menu==3)menu=0;	
		
		if(menu==0){
			DrawMap2(0,OVERLAY_ROW,map_logo);
			overlayHeight=3;
		}else if(menu==1){
			DrawMap2(0,OVERLAY_ROW,map_frame);
			Print(1,OVERLAY_ROW+1,strInfo1);
			overlayHeight=3;
		}else if(menu==2){
			overlayHeight=0;
		}
	
		SetOverlay(OVERLAY_PRI_HI+overlayHeight);
	}


	if(joy&BTN_SR){
		if(vx<138) vx+=1;
	}
	
	if(joy&BTN_SL){
		if(vx>0) vx-=1;		
	}

	if(joy&BTN_RIGHT){
		sx++;
		if(sx>=X_SCROLL_WRAP) sx=0;
		vx++;
	}
	
	if(joy&BTN_LEFT){
		sx--;
		if(sx==0xff) sx=(X_SCROLL_WRAP-1);
		vx--;
	}

	if(joy&BTN_UP){
		sy--;
		vy--;
	}
	
	if(joy&BTN_DOWN){
		sy++;
		vy++;
	}
	
	if(joy&BTN_SELECT){
		SetMixerVoice(0,0,0,0);
		SetMixerVoice(1,0,0,0);
		SetMixerVoice(2,0,0,0);
		SetMixerVoice(3,0,0,0);
		while(ReadJoypad(0)!=0);
	}

	SetScrolling(sx,sy);
	lastbuttons=joy;

	return 0;
}


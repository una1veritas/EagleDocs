#include <stdbool.h>
#include <avr/io.h>
#include <stdlib.h>
#include <avr/pgmspace.h>
#include "kernel/uzebox.h"
#include "data/fonts.pic.inc"
#include "data/colorbars.pic.inc"
#include "data/colorbars.map.inc"
const char strHello[] PROGMEM ="HELLO WORLD FROM THE FUZEBOX!";
const char strPlayer1[] PROGMEM ="PLAYER 1:         ";

int main(){
  unsigned int joy;

  ClearVram();

  SetTileTable(colorbars);
  SetFontTable(fonts);
  DrawMap(0,0,map_colorbars);
  Print(7,12,strHello);
  Print(7,15,strPlayer1);

  while (1) {
    WaitVsync(1);  // 30Hz = 33mS between frames
    joy = ReadJoypad(0);
  
    // read paddle controls

    
    if (joy & BTN_UP) {
      PrintChar(20,15,'U');
    } else {
      PrintChar(20,15, ' ');
    }

    if(joy&BTN_DOWN){
      PrintChar(21,15,'D');
    } else {
      PrintChar(21,15, ' ');
    }

    if(joy&BTN_LEFT){
      PrintChar(22,15,'L');
    } else {
      PrintChar(22,15, ' ');
    }

    if(joy&BTN_RIGHT){
      PrintChar(23,15,'R');
    } else {
      PrintChar(23,15, ' ');
    }

    if(joy&BTN_A){
      PrintChar(24,15,'A');
    } else {
      PrintChar(24,15, ' ');
    }
    
    if(joy&BTN_B){
      PrintChar(25,15,'B');
    } else {
      PrintChar(25,15, ' ');
    }

    if(joy&BTN_X){
      PrintChar(26,15,'X');
    } else {
      PrintChar(26,15, ' ');
    }

    if(joy&BTN_Y){
      PrintChar(27,15,'Y');
    } else {
      PrintChar(27,15, ' ');
    }

    if(joy&BTN_SR){
      PrintChar(28,15,'S');
      PrintChar(29,15,'R');
    } else {
      PrintChar(28,15, ' ');
      PrintChar(29,15, ' ');
    }

    if(joy&BTN_SL){
      PrintChar(30,15,'S');
      PrintChar(31,15,'L');
    } else {
      PrintChar(30,15, ' ');
      PrintChar(31,15, ' ');
    }
  }
}
